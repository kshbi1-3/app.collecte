package com.mavis.dicecollector.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.mavis.dicecollector.R
import com.mavis.dicecollector.config.AgentConfig
import com.mavis.dicecollector.orchestrator.AgentController
import com.mavis.dicecollector.ui.MainActivity
import com.mavis.dicecollector.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Long-running foreground service. Holds a partial wake lock while a cycle is
 * active, releases it during the cooldown period.
 *
 * Started by:
 *  - WorkManager ([com.mavis.dicecollector.service.PeriodicWorker])
 *  - [PushTriggerService] on Parchisi Star notifications
 *  - Manual "Run now" action from the UI
 */
class DiceCollectorService : Service() {

    private val supervisor = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Default + supervisor)
    private var wakeLock: PowerManager.WakeLock? = null
    private var cycleJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Logger.i("DiceCollectorService onCreate")
        ensureChannel(this)
        startForegroundCompat()
        startWatchingGate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Logger.d("DiceCollectorService onStartCommand: ${intent?.action}")
        when (intent?.action) {
            ACTION_RUN_NOW -> startCycle(reason = "user")
            ACTION_PUSH -> startCycle(reason = "push")
            else -> startCycle(reason = "scheduled")
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Keep running when the user swipes the app away.
        val restart = Intent(applicationContext, DiceCollectorService::class.java)
        restart.action = ACTION_RUN_NOW
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            applicationContext.startForegroundService(restart)
        } else {
            applicationContext.startService(restart)
        }
    }

    override fun onDestroy() {
        Logger.i("DiceCollectorService onDestroy")
        scope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    private fun startWatchingGate() {
        scope.launch {
            AgentController.gate(this@DiceCollectorService)
                .collectLatest { allowed ->
                    if (allowed) {
                        if (cycleJob?.isActive != true) {
                            startCycle(reason = "gate_open")
                        }
                    } else {
                        Logger.d("Gate closed — pausing cycle")
                        cycleJob?.cancel()
                        releaseWakeLock()
                    }
                }
        }
    }

    private fun startCycle(reason: String) {
        if (cycleJob?.isActive == true) {
            Logger.d("Cycle already running — ignoring start ($reason)")
            return
        }
        acquireWakeLock()
        cycleJob = scope.launch {
            try {
                AgentController.runOnce(this@DiceCollectorService, reason)
            } catch (t: Throwable) {
                Logger.e("Cycle failed: ${t.message}", t)
            } finally {
                releaseWakeLock()
                stopForegroundCompatIfIdle()
            }
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "DiceCollector::cycle"
        ).apply {
            setReferenceCounted(false)
            acquire(AgentConfig.phaseTimeoutMs * (AgentConfig.maxPhaseRetries + 2))
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) {
                try { it.release() } catch (_: Throwable) {}
            }
        }
        wakeLock = null
    }

    private fun startForegroundCompat() {
        val notif = buildServiceNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                AgentConfig.NOTIF_ID_SERVICE,
                notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
            )
        } else {
            startForeground(AgentConfig.NOTIF_ID_SERVICE, notif)
        }
    }

    private fun stopForegroundCompatIfIdle() {
        // Stay foregrounded if a wake lock is still held or another cycle is pending.
        if (wakeLock?.isHeld == true) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_DETACH)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    private fun buildServiceNotification(): Notification {
        val tapIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, tapIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, AgentConfig.NOTIF_CHANNEL_SERVICE)
            .setSmallIcon(R.drawable.ic_dice)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        const val ACTION_RUN_NOW = "com.mavis.dicecollector.action.RUN_NOW"
        const val ACTION_PUSH = "com.mavis.dicecollector.action.PUSH"

        fun ensureChannel(context: Context) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(AgentConfig.NOTIF_CHANNEL_SERVICE) == null) {
                val ch = NotificationChannel(
                    AgentConfig.NOTIF_CHANNEL_SERVICE,
                    context.getString(R.string.notif_channel_service),
                    NotificationManager.IMPORTANCE_LOW,
                ).apply {
                    description = context.getString(R.string.notif_channel_service_desc)
                    setShowBadge(false)
                }
                nm.createNotificationChannel(ch)
            }
            if (nm.getNotificationChannel(AgentConfig.NOTIF_CHANNEL_ALERTS) == null) {
                val ch = NotificationChannel(
                    AgentConfig.NOTIF_CHANNEL_ALERTS,
                    context.getString(R.string.notif_channel_alerts),
                    NotificationManager.IMPORTANCE_HIGH,
                ).apply {
                    description = context.getString(R.string.notif_channel_alerts_desc)
                }
                nm.createNotificationChannel(ch)
            }
        }

        fun start(context: Context, action: String = ACTION_RUN_NOW) {
            val intent = Intent(context, DiceCollectorService::class.java).apply {
                this.action = action
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }
}