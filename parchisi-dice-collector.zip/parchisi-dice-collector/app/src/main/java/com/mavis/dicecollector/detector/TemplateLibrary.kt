package com.mavis.dicecollector.detector

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.mavis.dicecollector.util.Logger
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Loads `/assets/templates/*.png` once and caches the converted OpenCV [Mat].
 *
 * Templates are grayscale.  Larger templates slow down matching — keep them
 * cropped to the icon / button of interest.
 */
class TemplateLibrary(private val context: Context) {

    private val cache = ConcurrentHashMap<String, Mat>()

    fun load(name: String): Mat? {
        cache[name]?.let { return it }
        return try {
            val bmp = BitmapFactory.decodeStream(context.assets.open("templates/$name"))
                ?: return null
            val mat = Mat(bmp.height, bmp.width, CvType.CV_8UC4)
            Utils.bitmapToMat(bmp, mat)
            val gray = Mat()
            org.opencv.imgproc.Imgproc.cvtColor(mat, gray, org.opencv.imgproc.Imgproc.COLOR_RGBA2GRAY)
            mat.release()
            cache[name] = gray
            Logger.d("Template loaded: $name (${gray.cols()}x${gray.rows()})")
            gray
        } catch (t: Throwable) {
            Logger.w("Template not found: $name — ${t.message}")
            null
        }
    }

    fun preloadAll() {
        try {
            val names = context.assets.list("templates") ?: return
            names.filter { it.endsWith(".png") }.forEach { load(it) }
        } catch (t: Throwable) {
            Logger.w("Failed to list templates: ${t.message}")
        }
    }

    fun dumpToCacheDir(name: String, source: Bitmap) {
        try {
            val dir = File(context.cacheDir, "screenshots").apply { mkdirs() }
            val file = File(dir, name)
            FileOutputStream(file).use { source.compress(Bitmap.CompressFormat.PNG, 90, it) }
            Logger.d("Screenshot dumped: ${file.absolutePath}")
        } catch (t: Throwable) {
            Logger.w("dumpToCacheDir failed: ${t.message}")
        }
    }
}