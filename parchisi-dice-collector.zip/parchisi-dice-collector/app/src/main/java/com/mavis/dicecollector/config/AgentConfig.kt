package com.mavis.dicecollector.config

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Centralised, mutable agent configuration.
 *
 * Resolution-independent coordinates are expressed as fractions in 0..1.
 * The [Coordinator] converts them to pixels based on the actual screen size.
 */
object AgentConfig {

    // --- Game / target -------------------------------------------------

    /** Package name of Parchisi Star.  Multiple candidates are tried in order. */
    val targetPackages: List<String> = listOf(
        "com.gametion.parchisi",
        "com.gametion.parchisi.star",
        "com.gametion.parchistar",
    )

    /** Activity to launch (first found in the manifest is used). */
    const val targetActivityAction = "android.intent.action.MAIN"

    // --- Region-of-interest definitions (fractions of screen) -----------
    //
    //       ┌────────────────────────────┐
    //       │  status bar                │
    //       │  0.00 ──────────── 1.00    │
    //       │       ┌────────┐           │   lucky dice icon ~ (0.86, 0.18)
    //       │       │ LOBBY  │           │
    //       │       └────────┘           │
    //       │  ┌──────────────────────┐  │
    //       │  │   central slot area  │  │   dice slots  3 rows × 0.30 / 0.45 / 0.60
    //       │  │     0.20 ──── 0.80   │  │
    //       │  └──────────────────────┘  │
    //       │   green COLLECT (0.50, 0.85) │
    //       └────────────────────────────┘

    /** Lucky Dice event entry icon (top-right of lobby). */
    val luckyDiceIconRegion = RectF(0.78f, 0.10f, 1.00f, 0.30f)

    /** Centre slots area — friend-sent dice + empty "Get dice 3" slot. */
    val slotsRegion = RectF(0.18f, 0.34f, 0.82f, 0.66f)

    /** "LUCKY DICE" banner region for screen verification. */
    val luckyDiceBannerRegion = RectF(0.20f, 0.04f, 0.80f, 0.12f)

    /** COLLECT button ROI (green CTA at the bottom). */
    val collectButtonRegion = RectF(0.30f, 0.78f, 0.70f, 0.92f)

    // --- Detection thresholds -----------------------------------------

    /** Minimum normalised match score for a template to be considered "found". */
    const val templateMatchThreshold: Double = 0.78

    /** Maximum fraction of red pixels required in the icon ROI to count as "badge present". */
    const val redBadgeMinFraction: Double = 0.012

    /** Minimum fraction of green pixels in the COLLECT ROI to consider the button visible. */
    const val collectButtonMinGreenFraction: Double = 0.18

    /** Maximum fraction of dashed-border pixels that distinguish the empty slot. */
    const val dashedSlotPixelFraction: Double = 0.10

    /** Fraction of white pixels required around a slot for it to count as "filled with dice". */
    const val filledSlotBorderFraction: Double = 0.045

    // --- Timing --------------------------------------------------------

    /** How long the agent waits after a successful collection before re-trying. */
    const val cycleCooldownMs: Long = 10 * 60 * 1000L           // 10 minutes

    /** How long the screen is woken for a screenshot. */
    const val screenOnForCaptureMs: Long = 800L

    /** Per-phase timeout. */
    const val phaseTimeoutMs: Long = 60 * 1000L                // 60 s

    /** Max retries per phase before backoff. */
    const val maxPhaseRetries: Int = 3

    /** Backoff after N consecutive failures. */
    const val failureBackoffMs: Long = 30 * 60 * 1000L         // 30 minutes

    // --- Push notification patterns -----------------------------------

    val pushNotificationPackages: Set<String> = setOf(
        "com.gametion.parchisi",
        "com.gametion.parchisi.star",
        "com.gametion.parchistar",
    )

    /** Regex applied to the notification title or text. */
    val pushTitlePatterns: List<Regex> = listOf(
        Regex("(?i)lucky\\s*dice"),
        Regex("(?i)free\\s*dice"),
        Regex("(?i)gift"),
    )

    // --- Battery -------------------------------------------------------

    /** Skip a cycle when battery is below this threshold (unless charging). */
    const val minBatteryPercent: Int = 15

    // --- WorkManager ---------------------------------------------------

    const val WORK_TAG_PERIODIC = "dice_collector_periodic"
    const val WORK_NAME_PERIODIC = "dice_collector_periodic_worker"

    /** Channel IDs. */
    const val NOTIF_CHANNEL_SERVICE = "dice_collector_service"
    const val NOTIF_CHANNEL_ALERTS = "dice_collector_alerts"

    const val NOTIF_ID_SERVICE = 0xD1C0
    const val NOTIF_ID_ALERT = 0xD1C1

    /** Foreground service notification. */
    const val FG_SERVICE_TYPE = "specialUse"
    const val FG_SERVICE_SUBTYPE = "automation_for_ParchisiStar_lucky_dice_collection"
}

/**
 * Plain-old-data rectangle in 0..1 fraction space.
 */
data class RectF(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    init {
        require(left in 0f..1f && top in 0f..1f && right in 0f..1f && bottom in 0f..1f) {
            "RectF values must be in [0..1]: $this"
        }
        require(right > left && bottom > top) { "RectF must be normalised: $this" }
    }
}

/**
 * Pixel-space rectangle, used after mapping from [RectF].
 */
data class RectPx(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
}

object ScreenInfo {
    @Volatile var widthPx: Int = 0
    @Volatile var heightPx: Int = 0
    @Volatile var density: Float = 1f

    fun capture(context: Context) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        val metrics = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
        widthPx = metrics.widthPixels
        heightPx = metrics.heightPixels
        density = metrics.density
    }
}

/**
 * Translates relative [RectF] coordinates to pixel [RectPx] for the current screen.
 */
object Coordinator {

    fun map(region: RectF): RectPx {
        val w = ScreenInfo.widthPx
        val h = ScreenInfo.heightPx
        require(w > 0 && h > 0) { "ScreenInfo not initialised" }
        return RectPx(
            left = (region.left * w).toInt(),
            top = (region.top * h).toInt(),
            right = (region.right * w).toInt(),
            bottom = (region.bottom * h).toInt(),
        )
    }

    fun mapFraction(x: Float, y: Float): Pair<Int, Int> {
        val w = ScreenInfo.widthPx
        val h = ScreenInfo.heightPx
        return ((x * w).toInt()) to ((y * h).toInt())
    }

    fun mapRectFractions(
        leftFrac: Float, topFrac: Float, rightFrac: Float, bottomFrac: Float
    ): RectPx = map(RectF(leftFrac, topFrac, rightFrac, bottomFrac))
}