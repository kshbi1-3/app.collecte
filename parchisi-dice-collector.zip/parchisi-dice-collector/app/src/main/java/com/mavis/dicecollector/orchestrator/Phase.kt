package com.mavis.dicecollector.orchestrator

/**
 * Sealed enumeration of the agent's lifecycle phases.
 *
 * The state machine is intentionally explicit: each transition is logged and
 * persisted so we can reconstruct the last cycle from the logs / prefs.
 */
sealed interface Phase {
    val name: String

    data object Idle : Phase { override val name = "IDLE" }
    data object Gating : Phase { override val name = "GATING" }
    data object Capture : Phase { override val name = "CAPTURE" }
    data object LaunchGame : Phase { override val name = "LAUNCH_GAME" }
    data object DetectLobby : Phase { override val name = "DETECT_LOBBY" }
    data object TapLuckyDice : Phase { override val name = "TAP_LUCKY_DICE" }
    data object VerifyLuckyDiceScreen : Phase { override val name = "VERIFY_LD_SCREEN" }
    data object ScanSlots : Phase { override val name = "SCAN_SLOTS" }
    data object MoveDice : Phase { override val name = "MOVE_DICE" }
    data object TapCollect : Phase { override val name = "TAP_COLLECT" }
    data object NoDice : Phase { override val name = "NO_DICE" }
    data object Cooldown : Phase { override val name = "COOLDOWN" }
    data object Failed : Phase { override val name = "FAILED" }
    data object Done : Phase { override val name = "DONE" }
}

enum class CycleOutcome {
    Collected,
    NoDice,
    Skipped,
    Failed,
}

sealed interface PhaseResult {
    data class Success(val next: Phase) : PhaseResult
    data class Retry(val next: Phase, val reason: String) : PhaseResult
    data class Fail(val reason: String) : PhaseResult
    data class Complete(val outcome: CycleOutcome) : PhaseResult
}