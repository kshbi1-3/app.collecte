package com.mavis.dicecollector.util

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedDeque

/**
 * Lightweight logger that streams to logcat, an in-memory ring buffer (for the
 * debug screen), and a rotating file on disk.
 */
object Logger {

    private const val TAG = "DiceCollector"
    private const val MAX_IN_MEMORY = 500

    private val buffer = ConcurrentLinkedDeque<Entry>()
    private val _flow = MutableSharedFlow<Entry>(extraBufferCapacity = 64)
    val flow: SharedFlow<Entry> = _flow.asSharedFlow()

    private var logFile: File? = null
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    private val fileDateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    @Synchronized
    fun init(context: Context) {
        val dir = File(context.getExternalFilesDir(null), "logs")
        if (!dir.exists()) dir.mkdirs()
        logFile = File(dir, "dice_collector_${fileDateFormat.format(Date())}.log")
    }

    fun d(msg: String) = log(Level.D, msg)
    fun i(msg: String) = log(Level.I, msg)
    fun w(msg: String) = log(Level.W, msg)
    fun e(msg: String, t: Throwable? = null) = log(Level.E, msg, t)

    private fun log(level: Level, msg: String, t: Throwable? = null) {
        val entry = Entry(System.currentTimeMillis(), level, msg, t)
        when (level) {
            Level.D -> Log.d(TAG, msg, t)
            Level.I -> Log.i(TAG, msg, t)
            Level.W -> Log.w(TAG, msg, t)
            Level.E -> Log.e(TAG, msg, t)
        }
        buffer.addLast(entry)
        while (buffer.size > MAX_IN_MEMORY) buffer.pollFirst()
        _flow.tryEmit(entry)
        appendToFile(entry)
    }

    private fun appendToFile(entry: Entry) {
        val file = logFile ?: return
        try {
            file.appendText(
                "${dateFormat.format(Date(entry.timestamp))} [${entry.level}] " +
                        "${entry.message}" +
                        (entry.throwable?.let { "\n${Log.getStackTraceString(it)}" } ?: "") +
                        "\n"
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to write log file: ${e.message}")
        }
    }

    fun snapshot(): List<Entry> = buffer.toList()

    fun logFiles(): List<File> =
        logFile?.parentFile?.listFiles { f -> f.name.startsWith("dice_collector_") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    enum class Level { D, I, W, E }

    data class Entry(
        val timestamp: Long,
        val level: Level,
        val message: String,
        val throwable: Throwable?,
    )
}