package com.mavis.dicecollector.detector

import android.graphics.Bitmap
import com.mavis.dicecollector.config.AgentConfig
import com.mavis.dicecollector.config.Coordinator
import com.mavis.dicecollector.config.RectPx
import com.mavis.dicecollector.util.Logger
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc

/**
 * Result of a template match.
 */
data class Match(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int,
    val score: Double,
) {
    val centerX: Int get() = x + width / 2
    val centerY: Int get() = y + height / 2
    fun passes(threshold: Double) = score >= threshold
}

/**
 * Detects UI elements on a captured screenshot.
 *
 * Strategies (in order of preference):
 *   1. Template matching against a known PNG (most precise).
 *   2. Color-histogram matching (for solid buttons like green COLLECT).
 *   3. Edge density in an ROI (for slot borders).
 */
class ImageDetector(
    private val templates: TemplateLibrary,
) {

    private var lastGray: Mat? = null

    /**
     * Updates the working buffer.  Call this whenever a new screenshot is captured.
     */
    fun setScreenshot(bitmap: Bitmap) {
        val rgba = Mat(bitmap.height, bitmap.width, CvType.CV_8UC4)
        org.opencv.android.Utils.bitmapToMat(bitmap, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()
        lastGray?.release()
        lastGray = gray
    }

    /** Returns the working buffer or null if no screenshot has been fed. */
    fun gray(): Mat? = lastGray

    /**
     * Locates the best occurrence of [templateName] in the **entire** screenshot.
     * Returns null if no candidate passes [threshold].
     */
    fun findTemplate(templateName: String, threshold: Double = AgentConfig.templateMatchThreshold): Match? {
        val gray = lastGray ?: return null.also { Logger.w("findTemplate: no screenshot") }
        val tpl = templates.load(templateName) ?: return null

        val result = Mat()
        Imgproc.matchTemplate(gray, tpl, result, Imgproc.TM_CCOEFF_NORMED)
        val mm = Core.minMaxLoc(result)
        result.release()
        val score = mm.maxVal
        val loc = mm.maxLoc
        if (score < threshold) {
            Logger.d("findTemplate($templateName): score=$score < $threshold")
            return null
        }
        return Match(
            x = loc.x.toInt(),
            y = loc.y.toInt(),
            width = tpl.cols(),
            height = tpl.rows(),
            score = score,
        )
    }

    /**
     * Locates the best occurrence of [templateName] **within** the supplied
     * ROI.  Useful for confirming the COLLECT button is at the bottom.
     */
    fun findTemplateInRoi(
        templateName: String,
        roi: RectPx,
        threshold: Double = AgentConfig.templateMatchThreshold,
    ): Match? {
        val gray = lastGray ?: return null
        val tpl = templates.load(templateName) ?: return null

        val cropped = Mat(gray, Rect(roi.left, roi.top, roi.width, roi.height))
        val result = Mat()
        Imgproc.matchTemplate(cropped, tpl, result, Imgproc.TM_CCOEFF_NORMED)
        val mm = Core.minMaxLoc(result)
        cropped.release()
        result.release()

        val score = mm.maxVal
        val loc = mm.maxLoc
        if (score < threshold) return null
        return Match(
            x = loc.x.toInt() + roi.left,
            y = loc.y.toInt() + roi.top,
            width = tpl.cols(),
            height = tpl.rows(),
            score = score,
        )
    }

    /**
     * Returns the fraction of pixels in [roi] whose hue is in the red band
     * (0°..15° or 165°..180° on the HSV wheel).
     */
    fun redFraction(roi: RectPx): Double {
        val gray = lastGray ?: return 0.0
        val rgb = Mat()
        Imgproc.cvtColor(gray, rgb, Imgproc.COLOR_GRAY2RGB)
        val hsv = Mat()
        Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
        rgb.release()

        val mask1 = Mat()
        val mask2 = Mat()
        Core.inRange(hsv, Scalar(0.0, 100.0, 100.0), Scalar(10.0, 255.0, 255.0), mask1)
        Core.inRange(hsv, Scalar(160.0, 100.0, 100.0), Scalar(180.0, 255.0, 255.0), mask2)
        val mask = Mat()
        Core.add(mask1, mask2, mask)
        mask1.release(); mask2.release()

        val cropped = Mat(mask, Rect(roi.left, roi.top, roi.width, roi.height))
        val total = (roi.width * roi.height).toDouble()
        val red = Core.countNonZero(cropped).toDouble()
        cropped.release(); mask.release(); hsv.release()
        return red / total
    }

    /**
     * Returns the fraction of pixels in [roi] matching the green band
     * (Hue 35..85, Saturation > 100, Value > 100).
     */
    fun greenFraction(roi: RectPx): Double {
        val gray = lastGray ?: return 0.0
        val rgb = Mat()
        Imgproc.cvtColor(gray, rgb, Imgproc.COLOR_GRAY2RGB)
        val hsv = Mat()
        Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
        rgb.release()

        val mask = Mat()
        Core.inRange(hsv, Scalar(35.0, 100.0, 100.0), Scalar(85.0, 255.0, 255.0), mask)

        val cropped = Mat(mask, Rect(roi.left, roi.top, roi.width, roi.height))
        val total = (roi.width * roi.height).toDouble()
        val green = Core.countNonZero(cropped).toDouble()
        cropped.release(); mask.release(); hsv.release()
        return green / total
    }

    /**
     * For each row of slots in the central slot area, returns whether the
     * slot has a full white border (i.e. holds a friend-sent dice).
     *
     * Returns a list of [SlotInfo] ordered top-to-bottom.
     */
    fun analyzeSlots(roi: RectPx = Coordinator.map(AgentConfig.slotsRegion)): List<SlotInfo> {
        val gray = lastGray ?: return emptyList()
        val cropped = Mat(gray, Rect(roi.left, roi.top, roi.width, roi.height))

        val edges = Mat()
        Imgproc.Canny(cropped, edges, 80.0, 200.0)

        // Divide the ROI horizontally into 3 equal rows.
        val rowHeight = roi.height / 3
        val results = mutableListOf<SlotInfo>()
        for (i in 0 until 3) {
            val rowTop = i * rowHeight
            val rowRect = Rect(0, rowTop, roi.width, rowHeight)
            val rowMat = Mat(edges, rowRect)
            val nonZero = Core.countNonZero(rowMat).toDouble()
            val area = (roi.width * rowHeight).toDouble()
            val density = nonZero / area
            results += SlotInfo(
                rowIndex = i,
                topInScreen = roi.top + rowTop,
                centerXInScreen = roi.centerX,
                centerYInScreen = roi.top + rowTop + rowHeight / 2,
                borderDensity = density,
                isLikelyFilled = density > AgentConfig.filledSlotBorderFraction * 4,
            )
            rowMat.release()
        }
        edges.release()
        cropped.release()
        return results
    }

    /**
     * Returns the centre of mass of green pixels in [roi] — i.e. the location
     * of the COLLECT button.  Returns null if not enough green is present.
     */
    fun collectButtonCenter(roi: RectPx): Point? {
        val gray = lastGray ?: return null
        val rgb = Mat()
        Imgproc.cvtColor(gray, rgb, Imgproc.COLOR_GRAY2RGB)
        val hsv = Mat()
        Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
        rgb.release()

        val mask = Mat()
        Core.inRange(hsv, Scalar(35.0, 100.0, 100.0), Scalar(85.0, 255.0, 255.0), mask)
        val cropped = Mat(mask, Rect(roi.left, roi.top, roi.width, roi.height))

        // Compute moments.
        val moments = Imgproc.moments(cropped, true)
        cropped.release(); mask.release(); hsv.release()

        if (moments.m00 < 30.0) return null
        val cx = moments.m10 / moments.m00
        val cy = moments.m01 / moments.m00
        return Point(cx + roi.left, cy + roi.top)
    }

    /**
     * Identifies the dashed-border empty slot ("Get dice 3").  Returns its
     * centre in screen coords, or null if no dashed pattern is detected.
     */
    fun dashedSlotCenter(roi: RectPx = Coordinator.map(AgentConfig.slotsRegion)): Point? {
        val gray = lastGray ?: return null
        val cropped = Mat(gray, Rect(roi.left, roi.top, roi.width, roi.height))
        val edges = Mat()
        Imgproc.Canny(cropped, edges, 80.0, 200.0)

        // Look for short edges (the dashes) — apply a morphological close first.
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, org.opencv.core.Size(3.0, 3.0))
        val closed = Mat()
        Imgproc.morphologyEx(edges, closed, Imgproc.MORPH_CLOSE, kernel)
        kernel.release(); edges.release()

        // The dashed slot tends to be the *least* edge-dense row (because it's empty).
        val rowHeight = roi.height / 3
        var bestRow = -1
        var minDensity = Double.MAX_VALUE
        for (i in 0 until 3) {
            val rowMat = Mat(closed, Rect(0, i * rowHeight, roi.width, rowHeight))
            val density = Core.countNonZero(rowMat).toDouble() / (roi.width * rowHeight)
            rowMat.release()
            if (density < minDensity) {
                minDensity = density
                bestRow = i
            }
        }
        closed.release(); cropped.release()

        if (bestRow < 0 || minDensity > AgentConfig.dashedSlotPixelFraction * 8) {
            return null
        }
        return Point(
            roi.centerX.toDouble(),
            (roi.top + bestRow * rowHeight + rowHeight / 2).toDouble()
        )
    }

    /**
     * Lightweight smoke-test used by the orchestrator to confirm the screen
     * is not black (e.g. screen-off capture glitch).
     */
    fun isLikelyBlackScreen(): Boolean {
        val gray = lastGray ?: return true
        val mean = Core.mean(gray).`val`[0]
        return mean < 6.0
    }

    /**
     * Returns the brightest pixel coordinates in the given ROI — handy when the
     * target is a bright icon on a darker background.
     */
    fun brightestPoint(roi: RectPx): Point? {
        val gray = lastGray ?: return null
        val cropped = Mat(gray, Rect(roi.left, roi.top, roi.width, roi.height))
        val mm = Core.minMaxLoc(cropped)
        cropped.release()
        if (mm.maxVal < 100.0) return null
        return Point(mm.maxLoc.x + roi.left, mm.maxLoc.y + roi.top)
    }
}

data class SlotInfo(
    val rowIndex: Int,
    val topInScreen: Int,
    val centerXInScreen: Int,
    val centerYInScreen: Int,
    val borderDensity: Double,
    val isLikelyFilled: Boolean,
)