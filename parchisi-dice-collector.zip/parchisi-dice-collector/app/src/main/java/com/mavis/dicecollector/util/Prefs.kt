package com.mavis.dicecollector.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Typed wrapper around [EncryptedSharedPreferences] for sensitive prefs (last
 * run, retry count, custom coordinate overrides).
 *
 * For settings that the OS already exposes (battery optimisation, accessibility)
 * we deliberately do NOT persist a flag here — we query the live system state.
 */
object Prefs {

    private const val FILE = "dice_collector_secure_prefs"

    private const val KEY_LAST_RUN_AT = "last_run_at_ms"
    private const val KEY_LAST_RESULT = "last_result"
    private const val KEY_CONSECUTIVE_FAILS = "consecutive_fails"
    private const val KEY_INTERVAL_MINUTES = "interval_minutes"
    private const val KEY_WIFI_ONLY = "wifi_only"
    private const val KEY_TOTAL_COLLECTED = "total_collected"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        prefs = EncryptedSharedPreferences.create(
            context,
            FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    var lastRunAtMs: Long
        get() = prefs.getLong(KEY_LAST_RUN_AT, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_RUN_AT, value).apply()

    var lastResult: String
        get() = prefs.getString(KEY_LAST_RESULT, "idle") ?: "idle"
        set(value) = prefs.edit().putString(KEY_LAST_RESULT, value).apply()

    var consecutiveFails: Int
        get() = prefs.getInt(KEY_CONSECUTIVE_FAILS, 0)
        set(value) = prefs.edit().putInt(KEY_CONSECUTIVE_FAILS, value).apply()

    var intervalMinutes: Int
        get() = prefs.getInt(KEY_INTERVAL_MINUTES, 10)
        set(value) = prefs.edit().putInt(KEY_INTERVAL_MINUTES, value).apply()

    var wifiOnly: Boolean
        get() = prefs.getBoolean(KEY_WIFI_ONLY, true)
        set(value) = prefs.edit().putBoolean(KEY_WIFI_ONLY, value).apply()

    var totalCollected: Int
        get() = prefs.getInt(KEY_TOTAL_COLLECTED, 0)
        set(value) = prefs.edit().putInt(KEY_TOTAL_COLLECTED, value).apply()

    fun bumpTotalCollected(by: Int = 1) {
        totalCollected = totalCollected + by
    }

    fun resetFailCounter() {
        consecutiveFails = 0
    }
}