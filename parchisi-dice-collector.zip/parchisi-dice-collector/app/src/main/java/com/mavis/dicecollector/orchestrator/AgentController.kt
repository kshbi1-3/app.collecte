package com.mavis.dicecollector.orchestrator

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import com.mavis.dicecollector.config.AgentConfig
import com.mavis.dicecollector.config.Coordinator
import com.mavis.dicecollector.config.RectPx
import com.mavis.dicecollector.detector.ImageDetector
import com.mavis.dicecollector.detector.TemplateLibrary
import com.mavis.dicecollector.gating.WiFiGatekeeper
import com.mavis.dicecollector.service.DiceCollectorA11y
import com.mavis.dicecollector.util.Logger
import com.mavis.dicecollector.util.Prefs
import com.mavis.dicecollector.util.ScreenCapture
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withTimeoutOrNull
import org.opencv.core.Point
import java.io.File
import java.io.FileOutputStream

/**
 * Top-level orchestrator.  Implements the 3-phase state machine documented in
 * [docs/FUNCTIONAL_SPEC.md].
 *
 * Designed to be called from any entry point: the foreground service, the
 * push trigger, the WorkManager worker, or the manual "Run now" button.
 */
object AgentController {

    @Volatile private var mediaProjectionData: Intent? = null

    fun setMediaProjectionData(data: Intent) {
        mediaProjectionData = data
    }

    fun hasMediaProjection(): Boolean = mediaProjectionData != null

    fun gate(context: Context): Flow<Boolean> = WiFiGatekeeper(context.applicationContext).allowedFlow()

    /**
     * Runs a single cycle.  Returns true if rewards were collected (or the
     * cycle cleanly found no dice), false on failure.
     */
    suspend fun runOnce(context: Context, reason: String): Boolean {
        val app = context.applicationContext
        Logger.i("=== Cycle start (reason=$reason) ===")
        Prefs.lastRunAtMs = System.currentTimeMillis()

        var phase: Phase = Phase.Gating
        var retries = 0
        val startTs = System.currentTimeMillis()

        while (true) {
            Logger.i("→ $phase")
            val result: PhaseResult = when (phase) {
                Phase.Gating -> gatePhase(app)
                Phase.Capture -> capturePhase(app)
                Phase.LaunchGame -> launchGamePhase(app)
                Phase.DetectLobby -> detectLobbyPhase(app)
                Phase.TapLuckyDice -> tapLuckyDicePhase(app)
                Phase.VerifyLuckyDiceScreen -> verifyLuckyDiceScreenPhase(app)
                Phase.ScanSlots -> scanSlotsPhase(app)
                Phase.MoveDice -> moveDicePhase(app)
                Phase.TapCollect -> tapCollectPhase(app)
                Phase.NoDice -> noDicePhase(app)
                Phase.Cooldown -> cooldownPhase(app)
                Phase.Failed -> PhaseResult.Complete(CycleOutcome.Failed)
                Phase.Done -> PhaseResult.Complete(CycleOutcome.Collected)
                Phase.Idle -> PhaseResult.Success(Phase.Gating)
            }

            when (result) {
                is PhaseResult.Success -> {
                    retries = 0
                    phase = result.next
                }
                is PhaseResult.Retry -> {
                    retries += 1
                    if (retries > AgentConfig.maxPhaseRetries) {
                        Logger.w("Phase ${phase.name} exhausted retries: ${result.reason}")
                        Prefs.consecutiveFails = Prefs.consecutiveFails + 1
                        Prefs.lastResult = "failed:${phase.name}"
                        phase = Phase.Failed
                    } else {
                        Logger.w("Phase ${phase.name} retry $retries: ${result.reason}")
                        delay(1500L * retries)
                    }
                }
                is PhaseResult.Fail -> {
                    Logger.e("Phase ${phase.name} failed: ${result.reason}")
                    Prefs.consecutiveFails = Prefs.consecutiveFails + 1
                    Prefs.lastResult = "failed:${phase.name}:${result.reason}"
                    phase = Phase.Failed
                }
                is PhaseResult.Complete -> {
                    val elapsedMs = System.currentTimeMillis() - startTs
                    Logger.i("=== Cycle end (outcome=${result.outcome}) in ${elapsedMs}ms ===")
                    when (result.outcome) {
                        CycleOutcome.Collected -> {
                            Prefs.bumpTotalCollected(1)
                            Prefs.resetFailCounter()
                            Prefs.lastResult = "collected"
                        }
                        CycleOutcome.NoDice -> {
                            Prefs.lastResult = "no_dice"
                        }
                        CycleOutcome.Skipped -> {
                            Prefs.lastResult = "skipped"
                        }
                        CycleOutcome.Failed -> {
                            // Already recorded.
                        }
                    }
                    return result.outcome != CycleOutcome.Failed
                }
            }

            if (phase is Phase.Idle) {
                // Defensive — should not normally happen.
                delay(1000)
                phase = Phase.Gating
            }
        }
    }

    // --- Phase implementations ---------------------------------------

    private suspend fun gatePhase(context: Context): PhaseResult {
        val gate = WiFiGatekeeper(context)
        if (!gate.isAllowedNow()) {
            Logger.w("Gate closed — skipping cycle")
            return PhaseResult.Complete(CycleOutcome.Skipped)
        }
        return PhaseResult.Success(Phase.Capture)
    }

    private suspend fun capturePhase(context: Context): PhaseResult {
        val data = mediaProjectionData
            ?: return PhaseResult.Fail("media projection token missing — grant in Settings")
        val capture = ScreenCapture(context)
        val bitmap = withTimeoutOrNull(AgentConfig.phaseTimeoutMs) {
            capture.capture(data)
        } ?: return PhaseResult.Retry(Phase.Capture, "capture timeout")
        if (bitmap == null) return PhaseResult.Retry(Phase.Capture, "capture returned null")

        // Dump screenshot for debug.
        try {
            val dir = File(context.getExternalFilesDir(null), "debug_screenshots").apply { mkdirs() }
            FileOutputStream(File(dir, "shot_${System.currentTimeMillis()}.png"))
                .use { bitmap.compress(Bitmap.CompressFormat.PNG, 80, it) }
        } catch (_: Throwable) { /* non-fatal */ }

        // Inject bitmap into detector.
        val detector = currentDetector(context)
        detector.setScreenshot(bitmap)
        return PhaseResult.Success(Phase.LaunchGame)
    }

    private suspend fun launchGamePhase(context: Context): PhaseResult {
        val pkg = AgentConfig.targetPackages.firstOrNull { isInstalled(context, it) }
            ?: return PhaseResult.Fail("Parchisi Star not installed")
        val launch = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return PhaseResult.Fail("No launch intent for $pkg")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        context.startActivity(launch)
        delay(4500L) // give the game time to render
        return PhaseResult.Success(Phase.DetectLobby)
    }

    private suspend fun detectLobbyPhase(context: Context): PhaseResult {
        val detector = currentDetector(context)
        // Wait up to 15 s for the lobby to render.
        val deadline = System.currentTimeMillis() + 15_000
        while (System.currentTimeMillis() < deadline) {
            // Re-capture every iteration to track the loading state.
            val cap = captureOnce(context) ?: return PhaseResult.Retry(Phase.Capture, "re-capture failed")
            detector.setScreenshot(cap)
            val match = detector.findTemplate(
                "lobby_background.png",
                threshold = 0.70,
            )
            if (match != null) {
                Logger.d("Lobby detected (score=${match.score})")
                return PhaseResult.Success(Phase.TapLuckyDice)
            }
            delay(800)
        }
        return PhaseResult.Retry(Phase.DetectLobby, "lobby never appeared")
    }

    private suspend fun tapLuckyDicePhase(context: Context): PhaseResult {
        val a11y = DiceCollectorA11y.get()
            ?: return PhaseResult.Fail("AccessibilityService not enabled")
        val detector = currentDetector(context)
        val roi = Coordinator.map(AgentConfig.luckyDiceIconRegion)
        val match = detector.findTemplateInRoi("lucky_dice_icon.png", roi)
            ?: return PhaseResult.Retry(Phase.TapLuckyDice, "icon template not found")

        val redFrac = detector.redFraction(
            RectPx(match.x, match.y, match.x + match.width, match.y + match.height)
        )
        if (redFrac < AgentConfig.redBadgeMinFraction) {
            Logger.d("Icon present but red badge absent (frac=$redFrac)")
            // Allow tap anyway — sometimes the badge is rendered with a slight delay.
        }
        Logger.i("Tapping Lucky Dice at (${match.centerX}, ${match.centerY}) score=${match.score}")
        a11y.tap(match.centerX, match.centerY)
        delay(2200L)
        return PhaseResult.Success(Phase.VerifyLuckyDiceScreen)
    }

    private suspend fun verifyLuckyDiceScreenPhase(context: Context): PhaseResult {
        val cap = captureOnce(context) ?: return PhaseResult.Retry(Phase.Capture, "re-capture failed")
        val detector = currentDetector(context)
        detector.setScreenshot(cap)
        val roi = Coordinator.map(AgentConfig.luckyDiceBannerRegion)
        val match = detector.findTemplateInRoi("lucky_dice_banner.png", roi, threshold = 0.75)
        if (match == null) {
            return PhaseResult.Retry(Phase.VerifyLuckyDiceScreen, "banner not visible")
        }
        return PhaseResult.Success(Phase.ScanSlots)
    }

    private suspend fun scanSlotsPhase(context: Context): PhaseResult {
        val cap = captureOnce(context) ?: return PhaseResult.Retry(Phase.Capture, "re-capture failed")
        val detector = currentDetector(context)
        detector.setScreenshot(cap)
        val slots = detector.analyzeSlots()
        val filled = slots.filter { it.isLikelyFilled }
        Logger.d("Slots: ${slots.map { "[${it.rowIndex}] ${it.borderDensity}" }}")

        if (filled.isEmpty()) return PhaseResult.Success(Phase.NoDice)

        // Stash the analysis on the orchestrator context so MoveDice can read it.
        lastFilledSlots = filled
        return PhaseResult.Success(Phase.MoveDice)
    }

    @Volatile private var lastFilledSlots: List<com.mavis.dicecollector.detector.SlotInfo> = emptyList()

    private suspend fun moveDicePhase(context: Context): PhaseResult {
        val a11y = DiceCollectorA11y.get() ?: return PhaseResult.Fail("a11y missing")
        val detector = currentDetector(context)
        val target = detector.dashedSlotCenter()
            ?: return PhaseResult.Retry(Phase.MoveDice, "no dashed slot")
        var moved = 0
        for (slot in lastFilledSlots) {
            val ok = a11y.dragAndDrop(
                slot.centerXInScreen, slot.centerYInScreen,
                target.x.toInt(), target.y.toInt(),
            )
            Logger.i("Drag dice[${slot.rowIndex}] (${slot.centerXInScreen},${slot.centerYInScreen}) → " +
                    "(${target.x.toInt()},${target.y.toInt()}) ok=$ok")
            delay(900L)
            moved += 1
        }
        delay(1500L)
        return PhaseResult.Success(Phase.TapCollect)
    }

    private suspend fun tapCollectPhase(context: Context): PhaseResult {
        val a11y = DiceCollectorA11y.get() ?: return PhaseResult.Fail("a11y missing")
        val cap = captureOnce(context) ?: return PhaseResult.Retry(Phase.Capture, "re-capture failed")
        val detector = currentDetector(context)
        detector.setScreenshot(cap)
        val roi = Coordinator.map(AgentConfig.collectButtonRegion)
        if (detector.greenFraction(roi) < AgentConfig.collectButtonMinGreenFraction) {
            return PhaseResult.Retry(Phase.TapCollect, "collect button not green yet")
        }
        val center: Point = detector.collectButtonCenter(roi)
            ?: return PhaseResult.Retry(Phase.TapCollect, "no green mass")
        Logger.i("Tapping COLLECT at (${center.x.toInt()},${center.y.toInt()})")
        a11y.tap(center.x.toInt(), center.y.toInt())
        delay(2500L)
        return PhaseResult.Complete(CycleOutcome.Collected)
    }

    private suspend fun noDicePhase(@Suppress("UNUSED_PARAMETER") context: Context): PhaseResult {
        Logger.i("No dice — entering cooldown")
        return PhaseResult.Success(Phase.Cooldown)
    }

    private suspend fun cooldownPhase(@Suppress("UNUSED_PARAMETER") context: Context): PhaseResult {
        // Sleep in 30s chunks so the service can be cancelled gracefully.
        val until = System.currentTimeMillis() + AgentConfig.cycleCooldownMs
        while (System.currentTimeMillis() < until) {
            delay(30_000L)
            // Re-check gate: if Wi-Fi drops, abort cooldown early.
            // (Service will cancel us anyway, but be defensive.)
        }
        return PhaseResult.Complete(CycleOutcome.NoDice)
    }

    // --- Helpers -----------------------------------------------------

    private fun isInstalled(context: Context, pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0); true
    } catch (_: Exception) { false }

    private suspend fun captureOnce(context: Context): Bitmap? {
        val data = mediaProjectionData ?: return null
        return withTimeoutOrNull(AgentConfig.phaseTimeoutMs) {
            ScreenCapture(context).capture(data)
        }
    }

    @Volatile private var cachedDetector: ImageDetector? = null
    @Volatile private var cachedTemplateLib: TemplateLibrary? = null

    private fun currentDetector(context: Context): ImageDetector {
        cachedDetector?.let { return it }
        val lib = cachedTemplateLib ?: TemplateLibrary(context.applicationContext).also {
            it.preloadAll()
            cachedTemplateLib = it
        }
        return ImageDetector(lib).also { cachedDetector = it }
    }
}