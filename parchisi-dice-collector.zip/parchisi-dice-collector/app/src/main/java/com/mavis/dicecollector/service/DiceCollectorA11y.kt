package com.mavis.dicecollector.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.mavis.dicecollector.util.Logger

/**
 * Singleton-style accessibility service. We do NOT subscribe to events —
 * we only use the dispatch capabilities (gestures + window-tree introspection).
 */
class DiceCollectorA11y : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Logger.i("DiceCollectorA11y connected")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Logger.i("DiceCollectorA11y unbound")
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No-op — we poll on demand.
    }

    override fun onInterrupt() {
        Logger.w("DiceCollectorA11y interrupted")
    }

    // --- Public API used by the orchestrator ---------------------------

    fun isReady(): Boolean = instance != null

    /** Single point tap. */
    fun tap(x: Int, y: Int, durationMs: Long = 80L): Boolean {
        return dispatchGesture(buildTapGesture(x, y, durationMs), null, null)
    }

    /** Simple swipe (straight line). */
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 600L): Boolean {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs, true)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Drag-and-drop with a press hold then move. */
    fun dragAndDrop(
        fromX: Int, fromY: Int, toX: Int, toY: Int,
        pressDurationMs: Long = 250L,
        moveDurationMs: Long = 600L,
    ): Boolean {
        val path = Path().apply {
            moveTo(fromX.toFloat(), fromY.toFloat())
            lineTo(toX.toFloat(), toY.toFloat())
        }
        val stroke = GestureDescription.StrokeDescription(path, pressDurationMs, moveDurationMs, false)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun buildTapGesture(x: Int, y: Int, durationMs: Long): GestureDescription {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs, true)
        return GestureDescription.Builder().addStroke(stroke).build()
    }

    fun dumpActiveWindow(): String {
        val root = rootInActiveWindow ?: return "(no active window)"
        return "${root.packageName}/${root.className}"
    }

    /**
     * Find the first node whose text or contentDescription contains [needle]
     * (case-insensitive).  Returns the screen-space centre, or null.
     */
    fun findText(needle: String): Pair<Int, Int>? {
        val root = rootInActiveWindow ?: return null
        val target = needle.lowercase()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        while (stack.isNotEmpty()) {
            val n = stack.removeLast()
            val text = (n.text?.toString() ?: "")
            val desc = (n.contentDescription?.toString() ?: "")
            if (text.lowercase().contains(target) || desc.lowercase().contains(target)) {
                val bounds = Rect()
                n.getBoundsInScreen(bounds)
                if (bounds.centerX() > 0 && bounds.centerY() > 0) {
                    return bounds.centerX() to bounds.centerY()
                }
            }
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { stack.addLast(it) }
            }
        }
        return null
    }

    fun displayMetrics(): DisplayMetrics {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val out = DisplayMetrics()
        @Suppress("DEPRECATION")
        display.getRealMetrics(out)
        return out
    }

    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    companion object {
        @Volatile private var instance: DiceCollectorA11y? = null
        fun get(): DiceCollectorA11y? = instance
    }
}