package com.mavis.dicecollector.service

import android.app.Notification
import android.content.pm.PackageManager
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.mavis.dicecollector.config.AgentConfig
import com.mavis.dicecollector.util.Logger

/**
 * Wakes the foreground service when a Parchisi Star push arrives.
 *
 * The user must enable this listener in:
 *   Settings → Notifications → Device & app notifications → Dice Collector
 */
class PushTriggerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        Logger.i("PushTriggerService connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (!isInteresting(sbn)) return
        Logger.i("Push from ${sbn.packageName}: ")

        DiceCollectorService.start(applicationContext, DiceCollectorService.ACTION_PUSH)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // no-op
    }

    private fun isInteresting(sbn: StatusBarNotification): Boolean {
        val pkg = sbn.packageName ?: return false
        if (pkg !in AgentConfig.pushNotificationPackages) return false
        val n: Notification = sbn.notification
        val extras: Bundle = n.extras
        val title = extras.getString(Notification.EXTRA_TITLE).orEmpty()
        val text = extras.getString(Notification.EXTRA_TEXT).orEmpty()
        val big = extras.getString(Notification.EXTRA_BIG_TEXT).orEmpty()
        val blob = "$title $text $big"
        return AgentConfig.pushTitlePatterns.any { it.containsMatchIn(blob) }
    }

    /**
     * Convenience used by the UI to verify the listener is enabled.
     */
    fun isPackageAllowed(packageName: String): Boolean =
        try {
            val pkgs = activeNotifications.map { it.packageName }
            packageName in pkgs
        } catch (_: SecurityException) {
            false
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
}