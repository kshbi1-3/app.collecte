package com.mavis.dicecollector

import android.app.Application
import android.content.Intent
import android.os.Build
import com.mavis.dicecollector.config.AgentConfig
import com.mavis.dicecollector.config.ScreenInfo
import com.mavis.dicecollector.service.DiceCollectorService
import com.mavis.dicecollector.service.PeriodicWorker
import com.mavis.dicecollector.util.Logger
import com.mavis.dicecollector.util.Prefs
import org.opencv.android.OpenCVLoader

class DiceCollectorApp : Application() {

    override fun onCreate() {
        super.onCreate()
        Logger.init(this)
        Logger.i("=== App boot ===")
        Prefs.init(this)
        ScreenInfo.capture(this)
        DiceCollectorService.ensureChannel(this)
        OpenCVLoader.initLocal()
        Logger.i("OpenCV loaded: ${OpenCVLoader.OPENCV_VERSION}")

        PeriodicWorker.schedule(this)
    }

    companion object {
        fun startForegroundService(context: android.content.Context) {
            val intent = Intent(context, DiceCollectorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}