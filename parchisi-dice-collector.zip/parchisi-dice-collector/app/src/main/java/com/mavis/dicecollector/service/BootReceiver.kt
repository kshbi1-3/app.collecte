package com.mavis.dicecollector.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.mavis.dicecollector.util.Logger

/**
 * Reschedules the periodic worker on boot.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON") return
        Logger.i("BootReceiver fired")
        try {
            PeriodicWorker.schedule(context)
        } catch (t: Throwable) {
            Log.w("BootReceiver", "Failed to schedule worker", t)
        }
    }
}