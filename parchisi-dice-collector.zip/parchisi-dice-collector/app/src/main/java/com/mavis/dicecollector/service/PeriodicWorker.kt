package com.mavis.dicecollector.service

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.mavis.dicecollector.config.AgentConfig
import com.mavis.dicecollector.orchestrator.AgentController
import com.mavis.dicecollector.util.Logger
import com.mavis.dicecollector.util.Prefs
import java.util.concurrent.TimeUnit

/**
 * WorkManager entry point.  Runs every [Prefs.intervalMinutes] minutes subject to:
 *
 *  - Wi-Fi connected (NetworkType.UNMETERED)
 *  - Battery not low
 *
 * If [Prefs.intervalMinutes] is below WorkManager's 15-minute minimum we use a
 * chain of OneTimeWorkRequests that reschedule themselves.
 */
class PeriodicWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        Logger.i("PeriodicWorker tick")
        return try {
            val ok = AgentController.runOnce(applicationContext, reason = "periodic")
            if (ok) Result.success() else Result.retry()
        } catch (t: Throwable) {
            Logger.e("PeriodicWorker failed: ${t.message}", t)
            Result.retry()
        }
    }

    companion object {
        fun schedule(context: Context) {
            val wm = WorkManager.getInstance(context)
            val intervalMinutes = Prefs.intervalMinutes.coerceAtLeast(10)

            // Always replace existing.
            if (intervalMinutes >= 15) {
                val req = PeriodicWorkRequestBuilder<PeriodicWorker>(
                    intervalMinutes.toLong(), TimeUnit.MINUTES
                )
                    .setConstraints(
                        Constraints.Builder()
                            .setRequiredNetworkType(NetworkType.UNMETERED)
                            .setRequiresBatteryNotLow(true)
                            .build()
                    )
                    .addTag(AgentConfig.WORK_TAG_PERIODIC)
                    .build()
                wm.enqueueUniquePeriodicWork(
                    AgentConfig.WORK_NAME_PERIODIC,
                    ExistingPeriodicWorkPolicy.UPDATE,
                    req,
                )
            } else {
                // Below 15: chain one-time workers with self-rescheduling.
                val oneTime = OneTimeWorkRequestBuilder<PeriodicWorker>()
                    .setInitialDelay(intervalMinutes.toLong(), TimeUnit.MINUTES)
                    .setConstraints(
                        Constraints.Builder()
                            .setRequiredNetworkType(NetworkType.UNMETERED)
                            .build()
                    )
                    .addTag(AgentConfig.WORK_TAG_PERIODIC)
                    .build()
                wm.enqueueUniqueWork(
                    AgentConfig.WORK_NAME_PERIODIC,
                    ExistingWorkPolicy.REPLACE,
                    oneTime,
                )
            }
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(AgentConfig.WORK_NAME_PERIODIC)
        }
    }
}