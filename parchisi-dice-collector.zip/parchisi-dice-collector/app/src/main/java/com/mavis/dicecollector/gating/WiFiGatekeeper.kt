package com.mavis.dicecollector.gating

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.BatteryManager
import com.mavis.dicecollector.config.AgentConfig
import com.mavis.dicecollector.util.Logger
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Decides whether the agent is currently *allowed* to run.
 *
 * Allowed ⇔ all of:
 *  1. Connected to a network whose `NET_CAPABILITY_NOT_METERED` is true.
 *  2. The user-facing "Wi-Fi only" toggle is on (default).
 *  3. Battery is above [AgentConfig.minBatteryPercent] **or** the device is charging.
 */
class WiFiGatekeeper(context: Context) {

    private val appContext = context.applicationContext
    private val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val battery = appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    /**
     * Synchronous, point-in-time check.
     */
    fun isAllowedNow(): Boolean {
        val networkCheck = if (PrefsWifiOnly.read(appContext)) {
            hasStableWifi()
        } else {
            hasAnyValidatedNetwork()
        }
        val batteryCheck = batteryOk()
        Logger.d("WiFiGatekeeper: network=$networkCheck battery=$batteryCheck")
        return networkCheck && batteryCheck
    }

    fun hasStableWifi(): Boolean {
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    fun hasAnyValidatedNetwork(): Boolean {
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun batteryOk(): Boolean {
        val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val status = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        return level >= AgentConfig.minBatteryPercent || charging
    }

    /**
     * Reactive flow that emits `true` whenever the gate transitions open and
     * `false` whenever it closes.  Used by the service to wake / sleep.
     */
    fun allowedFlow(): Flow<Boolean> = callbackFlow {
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(isAllowedNow())
            }
            override fun onLost(network: Network) {
                trySend(isAllowedNow())
            }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                trySend(isAllowedNow())
            }
        }
        cm.registerNetworkCallback(req, cb)
        trySend(isAllowedNow())
        awaitClose { cm.unregisterNetworkCallback(cb) }
    }.distinctUntilChanged()

    fun currentSsid(): String? {
        @Suppress("DEPRECATION")
        val wm = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val info = wm.connectionInfo
        @Suppress("DEPRECATION")
        val raw = info.ssid ?: return null
        return raw.trim('"').takeIf { it.isNotBlank() && it != "<unknown ssid>" }
    }
}

/**
 * Read/write the user preference for Wi-Fi-only mode without pulling in
 * the entire [com.mavis.dicecollector.util.Prefs] (kept here to avoid an
 * import cycle in tests).
 */
object PrefsWifiOnly {
    fun read(context: Context): Boolean =
        context.getSharedPreferences("dice_collector_simple", Context.MODE_PRIVATE)
            .getBoolean("wifi_only", true)
    fun write(context: Context, value: Boolean) {
        context.getSharedPreferences("dice_collector_simple", Context.MODE_PRIVATE)
            .edit().putBoolean("wifi_only", value).apply()
    }
}