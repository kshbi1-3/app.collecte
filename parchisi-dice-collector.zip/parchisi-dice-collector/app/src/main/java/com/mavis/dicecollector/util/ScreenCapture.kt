package com.mavis.dicecollector.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Captures a single screenshot using a previously-acquired [MediaProjection] token.
 *
 * The token must be obtained once at runtime via
 * [MediaProjectionManager.createScreenCaptureIntent] / `startActivityForResult`,
 * then the result data Intent is passed in here.
 */
class ScreenCapture(private val context: Context) {

    private val handlerThread = HandlerThread("DiceCollectorCapture").apply { start() }
    private val handler = Handler(handlerThread.looper)

    /**
     * Returns a Bitmap screenshot of the entire screen.
     *
     * @param projectionData the Intent data returned by `getMediaProjectionResult()`.
     */
    suspend fun capture(projectionData: android.content.Intent): Bitmap {
        val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager
        val metrics = currentDisplayMetrics()
        return captureInternal(mpm, projectionData, metrics)
    }

    private suspend fun captureInternal(
        mpm: MediaProjectionManager,
        data: android.content.Intent,
        metrics: DisplayMetrics,
    ): Bitmap = suspendCancellableCoroutine { cont ->
        val projection = mpm.getMediaProjection(android.app.Activity.RESULT_OK, data)
        val reader = ImageReader.newInstance(
            metrics.widthPixels,
            metrics.heightPixels,
            PixelFormat.RGBA_8888,
            2,
        )

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                reader.close()
            }
        }, handler)

        val virtualDisplay: VirtualDisplay = projection.createVirtualDisplay(
            "DiceCollectorCapture",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler,
        )

        reader.setOnImageAvailableListener({ r ->
            try {
                val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                val planes = image.planes
                val buffer = planes[0].buffer
                val pixelStride = planes[0].pixelStride
                val rowStride = planes[0].rowStride
                val rowPadding = rowStride - pixelStride * metrics.widthPixels
                val bitmap = Bitmap.createBitmap(
                    metrics.widthPixels + rowPadding / pixelStride,
                    metrics.heightPixels,
                    Bitmap.Config.ARGB_8888,
                )
                bitmap.copyPixelsFromBuffer(buffer)
                image.close()
                virtualDisplay.release()
                projection.stop()
                reader.close()
                cont.resume(bitmap)
            } catch (t: Throwable) {
                cont.resumeWithException(t)
            }
        }, handler)

        cont.invokeOnCancellation {
            reader.close()
            virtualDisplay.release()
            projection.stop()
        }
    }

    private fun currentDisplayMetrics(): DisplayMetrics {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display: Display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        display.getRealMetrics(metrics)
        return metrics
    }
}