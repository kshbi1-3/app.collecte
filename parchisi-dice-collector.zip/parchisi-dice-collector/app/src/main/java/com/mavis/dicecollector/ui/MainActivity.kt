package com.mavis.dicecollector.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mavis.dicecollector.R
import com.mavis.dicecollector.databinding.ActivityMainBinding
import com.mavis.dicecollector.gating.WiFiGatekeeper
import com.mavis.dicecollector.orchestrator.AgentController
import com.mavis.dicecollector.service.DiceCollectorA11y
import com.mavis.dicecollector.service.DiceCollectorService
import com.mavis.dicecollector.service.PeriodicWorker
import com.mavis.dicecollector.util.Logger
import com.mavis.dicecollector.util.Prefs
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Minimal control panel: shows status, lets the user grant permissions, run a
 * cycle manually, and view the live log.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var logAdapter: LogAdapter

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            AgentController.setMediaProjectionData(result.data!!)
            binding.statusProjection.text = getString(R.string.label_active)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        logAdapter = LogAdapter()
        binding.logList.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = logAdapter
        }

        binding.btnRunNow.setOnClickListener {
            DiceCollectorService.start(this, DiceCollectorService.ACTION_RUN_NOW)
        }
        binding.btnGrantBattery.setOnClickListener {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:$packageName"))
            try { startActivity(intent) } catch (_: Throwable) { /* fallback */ }
        }
        binding.btnGrantA11y.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.btnGrantNl.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        binding.btnGrantProjection.setOnClickListener {
            requestProjection()
        }
        binding.switchWifiOnly.setOnCheckedChangeListener { _, isChecked ->
            com.mavis.dicecollector.gating.PrefsWifiOnly.write(this, isChecked)
            updateStatus()
        }
        binding.seekInterval.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                val minutes = (p.coerceAtLeast(5)).coerceAtMost(60)
                binding.labelIntervalValue.text = "$minutes min"
                if (fromUser) {
                    Prefs.intervalMinutes = minutes
                    PeriodicWorker.schedule(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Logger.flow.collectLatest { logAdapter.add(it) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                WiFiGatekeeper(this@MainActivity).allowedFlow().collectLatest { allowed ->
                    binding.statusWifi.text = if (allowed) getString(R.string.label_active)
                                              else getString(R.string.msg_wifi_required)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        logAdapter.submit(Logger.snapshot())
    }

    private fun updateStatus() {
        binding.statusA11y.text = if (DiceCollectorA11y.get() != null)
            getString(R.string.label_active) else getString(R.string.msg_grant_a11y)
        binding.statusNl.text = if (isNotificationServiceEnabled())
            getString(R.string.label_active) else getString(R.string.msg_grant_nl)
        binding.statusLastRun.text = if (Prefs.lastRunAtMs == 0L)
            getString(R.string.label_idle)
        else
            DateUtils.getRelativeTimeSpanString(Prefs.lastRunAtMs)
        binding.statusLastResult.text = Prefs.lastResult
        binding.statusTotal.text = getString(R.string.msg_collected, Prefs.totalCollected)
        binding.switchWifiOnly.isChecked = com.mavis.dicecollector.gating.PrefsWifiOnly.read(this)
        binding.seekInterval.progress = Prefs.intervalMinutes
        binding.labelIntervalValue.text = "${Prefs.intervalMinutes} min"
        binding.statusBattery.text =
            if (isBatteryOptimisationIgnored()) getString(R.string.label_active)
            else getString(R.string.msg_grant_battery_opt)
        binding.statusProjection.text =
            if (AgentController.hasMediaProjection()) getString(R.string.label_active)
            else getString(R.string.label_idle)
    }

    private fun isBatteryOptimisationIgnored(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val pkg = android.provider.Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners",
        ) ?: return false
        return pkg.split(":").any { it.equals(packageName, ignoreCase = true) }
    }

    private fun requestProjection() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}

private class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {
    private val items = mutableListOf<Logger.Entry>()

    fun submit(list: List<Logger.Entry>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun add(entry: Logger.Entry) {
        items.add(entry)
        if (items.size > 500) items.removeAt(0)
        notifyItemInserted(items.size - 1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false) as ViewGroup
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        holder.title.text = "[${e.level}] ${DateUtils.formatDateTime(null, e.timestamp, DateUtils.FORMAT_SHOW_TIME)}"
        holder.subtitle.text = e.message
    }

    override fun getItemCount(): Int = items.size

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(android.R.id.text1)
        val subtitle: TextView = view.findViewById(android.R.id.text2)
    }
}