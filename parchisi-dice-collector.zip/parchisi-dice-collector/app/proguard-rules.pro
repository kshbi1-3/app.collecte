# ProGuard rules
-keepattributes Signature, *Annotation*, EnclosingMethod, InnerClasses

# OpenCV
-keep class org.opencv.** { *; }
-dontwarn org.opencv.**

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** { volatile <fields>; }

# Accessibility callbacks — keep service entry points
-keep class com.mavis.dicecollector.service.DiceCollectorA11y { *; }
-keep class com.mavis.dicecollector.service.DiceCollectorService { *; }
-keep class com.mavis.dicecollector.service.PushTriggerService { *; }

# WorkManager workers
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.CoroutineWorker
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context,androidx.work.WorkerParameters);
}