# Dice Collector — Parchisi Star automation agent

A persistent background Android agent that automatically collects free dice
rewards from the **Lucky Dice** event inside the game **Parchisi Star**.

> ⚠️ This is an automation tool for a single, specific game event. It does **not**
> modify the game, does not inject code, and does not interact with the game
> server beyond the same UI taps a user would perform. Use responsibly.

## Architecture

```
+-------------------------------------+
|            UI (MainActivity)        |
+-------------------------------------+
              ▲                ▲
              │ start/stop     │ live log
              │                │
+-------------------------------------+
|        Foreground Service           |
|   (DiceCollectorService + WakeLock) |
+-------------------------------------+
              ▲
              │ triggers
              │
+--------+----------+  +-------------------+
| Notification      |  |  WorkManager       |
| Listener Service  |  |  PeriodicWorker   |
+--------+----------+  +-------------------+
              ▲                ▲
              │ push           │ scheduled tick
              │                │
              └──────┬─────────┘
                     ▼
+-------------------------------------+
|        AgentController              |
|   (state machine Phase 1 → 2 → 3)   |
+-------------------------------------+
              ▲
              │ uses
              │
+--------+----------+  +-------------------+  +----------------------+
| WiFiGatekeeper     |  | AccessibilitySvc   |  | ImageDetector        |
|                    |  | (gestures, taps)   |  | (OpenCV templates)   |
+--------+----------+  +-------------------+  +----------------------+
```

See [`docs/FUNCTIONAL_SPEC.md`](docs/FUNCTIONAL_SPEC.md) for the full spec and
[`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the design decisions.

## Build & install

```bash
# Requires Android SDK 34 + JDK 17
./gradlew :app:assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

## First-run checklist

1. Open the app.
2. Tap **Enable Accessibility service** → enable *Dice Collector accessibility*.
3. Tap **Enable Notification access** → enable *Dice Collector push trigger*.
4. Tap **Disable battery optimisation** → allow.
5. Tap **Allow screenshot capture** → grant MediaProjection consent.
6. (Optional) adjust interval, default is 10 minutes.
7. Tap **Run now** for a manual cycle, or just leave the service running.

## Template assets

The repo does **not** ship Parchisi Star assets (copyright).
Run [`scripts/extract_templates.py`](scripts/extract_templates.py) on an
emulator with Parchisi Star installed; it will save the cropped icons and
banner into `app/src/main/assets/templates/`.

Required files:

* `lobby_background.png` — 1080×1920 reference of the lobby.
* `lucky_dice_icon.png` — 220×220 cropped icon including the red badge.
* `lucky_dice_banner.png` — the **LUCKY DICE** title strip.
* `dashed_slot.png` — the "Get dice 3" empty placeholder.
* `collect_button.png` — fallback template for the green CTA.

## Testing on an emulator

```bash
emulator -avd ParchisiTest -no-snapshot &
adb install app/build/outputs/apk/debug/app-debug.apk
adb shell am start -n com.mavis.dicecollector.debug/com.mavis.dicecollector.ui.MainActivity
```

## Permissions rationale

| Permission | Why |
|---|---|
| `BIND_ACCESSIBILITY_SERVICE` | Tap on the Lucky Dice and COLLECT buttons. |
| `BIND_NOTIFICATION_LISTENER_SERVICE` | Wake the agent when Parchisi Star posts a notification. |
| `FOREGROUND_SERVICE_SPECIAL_USE` | Run as a foreground service on Android 14. |
| `WAKE_LOCK` | Keep the CPU running for the duration of a cycle. |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | Survive Doze. |
| `POST_NOTIFICATIONS` | Android 13+ notification posting. |
| `RECEIVE_BOOT_COMPLETED` | Auto-start the worker after a reboot. |