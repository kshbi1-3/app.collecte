#!/usr/bin/env python3
"""
Helper for capturing the image templates the agent needs.

How to use:
  1. Start an emulator with Parchisi Star installed.
  2. Navigate the game manually to the lobby AND to the Lucky Dice sub-menu.
  3. Take a screenshot of each (adb shell screencap) and save as lobby.png
     and lucky_dice.png.
  4. Run this script — it crops and saves the templates the agent expects.

Outputs (into app/src/main/assets/templates/):
  - lobby_background.png
  - lucky_dice_icon.png     (top-right of lobby)
  - lucky_dice_banner.png   (top of Lucky Dice sub-menu)
  - dashed_slot.png         (empty "Get dice 3" slot, manually selected)
  - collect_button.png      (green COLLECT button, manually selected)
"""

import argparse
import os
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("pip install Pillow", file=sys.stderr)
    sys.exit(1)


REPO_ROOT = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = REPO_ROOT / "app" / "src" / "main" / "assets" / "templates"


def crop(src: Path, box: tuple, dst_name: str) -> None:
    img = Image.open(src)
    cropped = img.crop(box)
    out_path = TEMPLATES_DIR / dst_name
    cropped.save(out_path)
    print(f"Wrote {out_path.relative_to(REPO_ROOT)} ({cropped.size})")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lobby", required=True, help="lobby.png screenshot")
    parser.add_argument("--lucky-dice", required=True, help="lucky_dice.png screenshot")
    parser.add_argument("--lobby-icon", nargs=4, type=int, metavar=("L", "T", "R", "B"),
                        default=(1380, 280, 1620, 520),
                        help="crop box for the Lucky Dice icon in lobby.png (px)")
    parser.add_argument("--banner", nargs=4, type=int, metavar=("L", "T", "R", "B"),
                        default=(400, 80, 1280, 220),
                        help="crop box for the LUCKY DICE banner in lucky_dice.png")
    parser.add_argument("--dashed-slot", nargs=4, type=int, metavar=("L", "T", "R", "B"),
                        default=(0, 0, 0, 0),
                        help="crop box for the dashed empty slot")
    parser.add_argument("--collect-btn", nargs=4, type=int, metavar=("L", "T", "R", "B"),
                        default=(0, 0, 0, 0),
                        help="crop box for the COLLECT button")
    args = parser.parse_args()

    TEMPLATES_DIR.mkdir(parents=True, exist_ok=True)
    lobby = Path(args.lobby)
    lucky = Path(args.lucky_dice)

    # Full lobby (we use the original PNG as background reference).
    crop(lobby, (0, 0, Image.open(lobby).width, Image.open(lobby).height),
         "lobby_background.png")

    # Lucky Dice icon (top-right ROI).
    crop(lobby, tuple(args.lobby_icon), "lucky_dice_icon.png")

    # Banner on the Lucky Dice sub-menu.
    crop(lucky, tuple(args.banner), "lucky_dice_banner.png")

    # Optional manual crops.
    if any(args.dashed_slot):
        crop(lucky, tuple(args.dashed_slot), "dashed_slot.png")
    if any(args.collect_btn):
        crop(lucky, tuple(args.collect_btn), "collect_button.png")


if __name__ == "__main__":
    main()