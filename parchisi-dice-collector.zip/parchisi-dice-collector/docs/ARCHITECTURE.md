# Architecture Decision Record

## ADR-001 — Why AccessibilityService instead of `uiautomator` shell?

`uiautomator` from `InstrumentationRegistry` only works inside a test process —
it cannot run as a persistent background trigger. `AccessibilityService` is the
**only** officially supported long-running input-injection channel that does
not require root. Trade-off: it must be enabled in Settings by the user.

## ADR-002 — Why OpenCV instead of ML Kit?

The detection targets are **icons we control the templates of** — perfect for
template matching. ML Kit adds ~20 MB to the APK and ~150 ms cold start per
detection. OpenCV adds ~6 MB and ~30 ms.

## ADR-003 — Why a foreground service + WorkManager?

* WorkManager alone cannot hold a partial wake lock.
* A foreground service alone will be killed during Doze on some OEMs even with
  `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`.
* The combination: service holds wake lock for the cycle duration, WorkManager
  schedules the next cycle.

## ADR-004 — Why partial wake lock + screen-on request only during capture?

Screen-on for the full cycle would drain the battery (~3× faster). We wake the
screen for ≤1 s per capture, which is enough for `MediaProjection` to grab a
frame and for `AccessibilityService` to inject taps (taps work with screen
off — only the screenshot capture needs the screen briefly on).

## ADR-005 — Coordinate mapping strategy

We store **relative coordinates in 0..1 space** (e.g. icon centre = `0.92, 0.06`)
plus a **device profile** (resolution + density). On first run we capture the
screen resolution from `WindowMetrics` and convert. This makes the agent
resolution-independent and avoids hard-coding pixels.

## ADR-006 — Push-notification trigger

`NotificationListenerService` is more reliable than polling
`NotificationManager.activeNotifications` because the latter only sees
notifications while the listener is bound. The service also handles
`onNotificationPosted` for cancelled notifications.