# Parchisi Dice Collector — Functional Specifications

> **Codename:** `parchisi-dice-collector`
> **Target:** Android 8.0 (API 26) → Android 14 (API 34)
> **Architecture:** Foreground Service + AccessibilityService + WorkManager + OpenCV image recognition

---

## 1. Product Summary

A persistent background agent that automatically collects free dice rewards from
the **"Lucky Dice"** event inside the game **Parchisi Star**.

The agent:

1. Wakes up either on a schedule (every 10 minutes) **or** when a Parchisi Star
   push notification arrives.
2. Verifies the device is on stable Wi-Fi.
3. Launches (or foregrounds) Parchisi Star.
4. Navigates to the **Lucky Dice** sub-menu using Computer Vision template
   matching on a captured screenshot of the lobby.
5. Detects up to 3 friend-sent dice in the centre slots.
6. Drags/taps each dice into the dashed "Get dice 3" slot.
7. Taps the green **COLLECT** button.
8. Sleeps for 10 minutes (low-power standby) and repeats.

The whole loop runs while the screen is off via `PARTIAL_WAKE_LOCK` plus
`AccessibilityService`-driven gestures.

---

## 2. High-Level Architecture

```
+------------------------------------------------------------------+
|                        Android OS                                |
+------------------------------------------------------------------+
        ^                     ^                       ^
        | notification        | scheduled             | UI events / screenshots
        |                     | tick                  |
+-------+--------+   +--------+--------+    +----------+----------+
| Notification   |   | WorkManager     |    | AccessibilityService|
| Listener       |   | PeriodicWorker  |    | (DiceCollectorA11y) |
| (trigger)      |   | (trigger)       |    | + screen capture     |
+-------+--------+   +--------+--------+    +----------+----------+
        \                     |                       /
         \                    |                      /
          +-------------------+----------------------+
                              v
                +-------------+--------------+
                | Orchestrator               |
                | (AgentController)          |
                |   - StateMachine           |
                |   - Phase 1 → 2 → 3        |
                +-------------+--------------+
                              |
                +-------------+--------------+
                | WiFiGatekeeper             |
                |   - NetworkCapabilities    |
                |   - validated + metered    |
                +-------------+--------------+
                              |
                +-------------+--------------+
                | ImageDetector (OpenCV)     |
                |   - screen capture         |
                |   - template matching      |
                |   - color heuristics       |
                +-------------+--------------+
                              |
                +-------------+--------------+
                | Foreground Service         |
                | (DiceCollectorService)     |
                |   - PARTIAL_WAKE_LOCK      |
                |   - START_STICKY           |
                |   - notification channel   |
                +----------------------------+
```

---

## 3. Module Breakdown

| Module | Package | Responsibility |
|---|---|---|
| `DiceCollectorApp` | `com.mavis.dicecollector` | Application class — initialises OpenCV, builds notification channel, schedules WorkManager |
| `WiFiGatekeeper` | `com.mavis.dicecollector.gating` | Polls `ConnectivityManager`. Returns `true` only when `NetworkCapabilities.NET_CAPABILITY_NOT_METERED` is present and validated |
| `DiceCollectorService` | `com.mavis.dicecollector.service` | Foreground service that holds the partial wake lock and owns the orchestrator lifecycle |
| `DiceCollectorA11y` | `com.mavis.dicecollector.service` | `AccessibilityService` exposing `dispatchTap(x,y)`, `dispatchSwipe(...)`, and `captureScreen()` |
| `PushTriggerService` | `com.mavis.dicecollector.service` | `NotificationListenerService` — wakes the agent when a Parchisi Star push arrives |
| `AgentController` | `com.mavis.dicecollector.orchestrator` | Drives the 3-phase state machine, persists run history, emits log events |
| `Phase` enum + `PhaseRunner` | `com.mavis.dicecollector.orchestrator` | Sealed-class state machine |
| `ImageDetector` | `com.mavis.dicecollector.detector` | Wraps OpenCV `Imgproc.matchTemplate` with multi-scale matching and a color-based fallback for solid-button detection |
| `TemplateLibrary` | `com.mavis.dicecollector.detector` | Loads `/assets/templates/*.png` once, caches `Mat` |
| `Templates` constants | `com.mavis.dicecollector.config` | File names + matching thresholds for each phase |
| `Coordinator` | `config` | Maps screen coordinates (dp-relative) → real pixel coordinates per device profile |
| `Prefs` | `util` | Encrypted SharedPreferences for last-run timestamps, retry counts, template overrides |
| `Logger` | `util` | Rolling file logger + in-memory ring buffer accessible via debug screen |

---

## 4. Functional Phases

### Phase 1 — Interface Recognition & Navigation

| Step | Action | Detection |
|---|---|---|
| 1.1 | Bring Parchisi Star to foreground | `ActivityManager` + package name `com.gametion.parchisi` (configurable) |
| 1.2 | Wait for lobby to render | Poll screen until matching score ≥ 0.85 for `lobby_background` template |
| 1.3 | Locate the **Lucky Dice** icon (top-right) | `matchTemplate(lucky_dice_icon.png)` + verify red badge via HSV red mask on ROI |
| 1.4 | Tap icon centre | `dispatchTap(x, y)` via `AccessibilityService` |

### Phase 2 — Dice Detection & Automatic Collection

| Step | Action | Detection |
|---|---|---|
| 2.1 | Verify **LUCKY DICE** screen | `matchTemplate(lucky_dice_banner.png)` ≥ 0.85 |
| 2.2 | Scan 3 slot regions | For each ROI: solid-white-border density check; convert to binary, count border pixels |
| 2.3 | Identify empty "Get dice 3" slot | Dashed-border template match (`dashed_slot.png`) |
| 2.4 | Tap each filled slot → empty slot | `dispatchSwipe(src, dst, 600ms)` |
| 2.5 | Wait for green **COLLECT** button | HSV green mask on bottom-centre ROI; centre of mass ≥ 30 px |
| 2.6 | Tap **COLLECT** | `dispatchTap` on centre of mass |
| 2.7 | If no dice detected → state `NO_DICE` | log + transition to idle |

### Phase 3 — Loop & Power Optimisation

| Trigger | Behaviour |
|---|---|
| Successful collection | Write timestamp to prefs → release wake lock → `WorkManager.enqueue` next run in 10 min |
| No dice available | Same as above (don't waste cycles) |
| Failed phase (3 retries) | Backoff 30 min, surface a notification |
| Parchisi Star push notification | Cancel pending WorkManager job → run immediately |
| Battery < 15% | Skip cycle, schedule next for when charging |
| Wi-Fi lost mid-run | Abort cleanly, release wake lock, wait for Wi-Fi gate to reopen |

---

## 5. Persistence & Scheduling

* **Foreground service** holds a `PARTIAL_WAKE_LOCK` while a cycle is running.
  When the cycle ends the wake lock is released and the service is started in
  the background but kept alive by the ongoing notification.
* **WorkManager `PeriodicWorkRequest`** every 10 minutes (minimum allowed by
  WorkManager is 15 min, so we use an initial 10-min `OneTimeWorkRequest`
  rescheduled by the service on success — this matches the requirement).
* **NotificationListenerService** triggers an immediate cycle when Parchisi Star
  posts a notification matching the configured patterns.
* **Doze / App Standby**: the service declares
  `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` and guides the user to disable battery
  optimisation for the app on first launch.

---

## 6. Screen-Off Execution Strategy

Three layers of defence to handle a turned-off screen:

1. `PARTIAL_WAKE_LOCK` keeps CPU running.
2. `AccessibilityService` can dispatch gestures **without** requiring the screen
   to be on — Android dispatches input to whatever the foreground app is.
3. `MediaProjection` is used to grab screenshots; this **does** require the
   screen-on state. The controller therefore:
   * Detects screen-off via `PowerManager.isInteractive()`.
   * If off → calls `PowerManager.WakeLock` with `ACQUIRE_CAUSES_WAKEUP` +
     `SCREEN_BRIGHT_WAKE_LOCK` for 800 ms just long enough to capture.
   * Drops back to off state immediately after capture.

This is the safest pattern that does not require root.

---

## 7. Template Assets

`/assets/templates/`:

* `lobby_background.png` — 1080×1920 reference frame of the lobby.
* `lucky_dice_icon.png` — 220×220 cropped icon including the red badge.
* `lucky_dice_banner.png` — the **LUCKY DICE** title strip.
* `dashed_slot.png` — the "Get dice 3" empty placeholder.
* `collect_button.png` — fallback template for the green CTA.

These are placeholder filenames; the repo includes a Python script
(`scripts/extract_templates.py`) that captures them from an emulator running
Parchisi Star for the first time.

---

## 8. Safety / Failure Handling

| Failure | Recovery |
|---|---|
| Template match score < 0.6 everywhere | Screenshot saved to `/sdcard/Download/dice_collector_debug/` for inspection, retry in 60 s |
| AccessibilityService disabled | Persistent notification with deep-link to settings |
| OpenCV native lib missing | Crash-safe fallback: parse `UiAutomator` dump for resource IDs |
| Repeated crashes (3 in a row) | Auto-disable and notify user |
| User opens app UI (debug overlay) | Agent pauses for 30 s |

---

## 9. Permissions

| Permission | Why |
|---|---|
| `INTERNET` | OpenCV model download is **not** needed, but `WorkManager` requires it. |
| `ACCESS_NETWORK_STATE` | Wi-Fi gating |
| `ACCESS_WIFI_STATE` | Wi-Fi SSID lookup (debug overlay) |
| `FOREGROUND_SERVICE` | Foreground service |
| `FOREGROUND_SERVICE_SPECIAL_USE` | Android 14 requirement for non-media foreground services |
| `WAKE_LOCK` | Partial wake lock |
| `RECEIVE_BOOT_COMPLETED` | Auto-start after reboot |
| `BIND_ACCESSIBILITY_SERVICE` | Required by accessibility declaration |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | Survive Doze |
| `POST_NOTIFICATIONS` | Android 13+ |
| `SYSTEM_ALERT_WINDOW` | Debug overlay (optional, declared with `optional="true"`) |